export const data = {
    categories: [
        {
            id: 1,
            title: 'Tradicionais',
            cover: 'https://i.postimg.cc/9DyFL8KB/bar6.jpg'
        },
        {
            id: 2,
            title: 'Elegantes',
            cover: 'https://i.postimg.cc/14YtXNDD/bar4.jpg'
        },
        {
            id: 3,
            title: 'Música ao Vivo',
            cover: 'https://i.postimg.cc/tn74DXG1/bar2.jpg'
        },
        {
            id: 4,
            title: 'Casuais',
            cover: 'https://i.postimg.cc/w7yBmTkZ/bar5.jpg'
        },
        {
            id: 5,
            title: 'Temáticos',
            cover: 'https://i.postimg.cc/8j2zBQK5/bar3.jpg'
        },
        {
            id: 6,
            title: 'Ar Livre',
            cover: 'https://i.postimg.cc/Lhs5mVgH/bar1.jpg'
        }
    ],
    products: [
        { id: 4, idCategory: 1, image: "https://i.postimg.cc/Lhs5mVgH/bar1.jpg", title: "Bahrem", description: "Ambiente sofisticado, ótimo para encontros e eventos.", price: 499.99 },
        { id: 23, idCategory: 1, image: "https://i.postimg.cc/tn74DXG1/bar2.jpg", title: "Simprão", description: "Bar com música ao vivo e petiscos deliciosos.", price: 49.99 },
        { id: 15, idCategory: 2, image: "https://i.postimg.cc/8j2zBQK5/bar3.jpg", title: "Bruxelas", description: "Bar aconchegante com um cardápio variado de drinks e cervejas artesanais.", price: 34.99 },
        { id: 9, idCategory: 2, image: "https://i.postimg.cc/14YtXNDD/bar4.jpg", title: "Petra", description: "Bar sofisticado, ideal para quem gosta de boa comida e bebida.", price: 79.99 },
        { id: 12, idCategory: 3, image: "https://i.postimg.cc/w7yBmTkZ/bar5.jpg", title: "Moema", description: "Ambiente descontraído e excelente para happy hour.", price: 59.99 },
        
    ]
}