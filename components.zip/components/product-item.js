import { Pressable, Text, Image, StyleSheet, View } from "react-native"
import { Link } from "expo-router"
import { data } from "../assets"

export const ProductItem = (props) => {
    return (
        <Link href={`/product/${props.data.id}`} asChild>
            <Pressable style={s.container}>
                <Image style={s.img} source={{ uri: props.data.image }} resizeMode="cover" />
                <View style={s.info}>
                    <Text style={s.productTitle}>{props.data.title}</Text>
                    <Text style={s.productDescription}>{props.data.description}</Text>
                    <Text style={s.productPrice}>R$ {props.data.price}</Text>
                </View>
            </Pressable>
        </Link>
    )
}

const s = StyleSheet.create({
    container: {
        flexDirection: 'row'
    },
    img: {
        width: 100,
        height: 100,
        borderRadius: 10,
        backgroundColor: '#CCCCCC',
        marginBottom: 10,
        marginRight: 20,

    },
    info: {
        flex: 1
    },
    productTitle: {
        fontWeight: 'bold',
        fontSize: 20,
        marginBottom: 10
    },
    productDescription: {
        fontStyle: 'italic'
    },
    productPrice: {
        color: 'green',
        fontWeight: 'bold',
        textAlign: 'right',
        fontSize: 15


    }

})