import { Pressable, Text, View, StyleSheet } from "react-native"


export const Button = ({ title, onPress }) => {
    return (
        <Pressable onPress={onPress} style={s.button}>
            <Text style={s.buttonText}>{title}</Text>
        </Pressable>
    )
}

const s = StyleSheet.create({
    button: {
        
    },
    buttonText:{

    }
})