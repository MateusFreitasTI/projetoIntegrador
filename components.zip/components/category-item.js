import { Pressable, Text } from "react-native"

export const CategoryItem = ({item}) =>{
    return(
        <Pressable style={s.container} onPress={handleClick}>
                    <Text>
                        {item.title}
                    </Text>
                </Pressable>
    )
}