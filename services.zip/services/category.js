import { data } from "../assets/index";

export const getAllCategories = ()=>{
    return data.categories;
}

export const getCategoryById = (id) =>{
    return data.categories.find(item => item.id === id)
}