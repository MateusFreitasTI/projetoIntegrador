import { data } from "../assets";

export const getAllProducts = ()=>{
    return data.products;
}

export const getProductById = (id) =>{
    return data.products.find(item => item.id === id)
}

export const getProductByCategory = (idCategory) =>{
    return data.products.filter(item => item.idCategory === idCategory)
}