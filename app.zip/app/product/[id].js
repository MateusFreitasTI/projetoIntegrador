import { router, Stack, useLocalSearchParams } from "expo-router";
import { SafeAreaView, StyleSheet, Text, View, Image, ScrollView, Button, Alert, TouchableOpacity, Modal, FlatList } from "react-native";
import React, { useState } from "react";
import { getProductById } from "../../services/product";

export default function Screen() {
    const { id } = useLocalSearchParams();
    const idProduct = parseInt(id);

    const product = getProductById(idProduct);
    if (!product) return router.back();

    const [selectedDate, setSelectedDate] = useState('');
    const [selectedTime, setSelectedTime] = useState('');
    const [showDateModal, setShowDateModal] = useState(false);
    const [showTimeModal, setShowTimeModal] = useState(false);

    const dates = Array.from({ length: 7 }, (_, i) => {
        const today = new Date();
        today.setDate(today.getDate() + i);
        return today.toISOString().split('T')[0];
    });

    const times = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);

    const handleBuyButton = () => {
        if (!selectedDate) {
            Alert.alert("Erro", "Por favor, selecione uma data.");
            return;
        }

        if (!selectedTime) {
            Alert.alert("Erro", "Por favor, selecione um horário.");
            return;
        }

        Alert.alert(
            "Reservado com sucesso!",
            `${product.title}\nSua reserva será enviada no e-mail\nDia: ${selectedDate}\nHorário: ${selectedTime}`
        );
    };

    return (
        <SafeAreaView style={s.container}>
            <Stack.Screen options={{ title: "" }} />
            <ScrollView style={s.area}>
                <Image style={s.img} source={{ uri: product.image }} resizeMode="cover" />
                <View style={s.campo}>
                    <Text style={s.title}>{product.title}</Text>
                    <Text style={s.description}>{product.description}</Text>
                    <Text style={s.price}>{product.price}</Text>
                </View>
                <View style={s.inputArea}>
                    <Text style={s.label}>Escolha o dia:</Text>
                    <TouchableOpacity
                        style={s.selectBox}
                        onPress={() => setShowDateModal(true)}
                    >
                        <Text style={s.selectText}>
                            {selectedDate || "Selecione uma data"}
                        </Text>
                    </TouchableOpacity>
                    <Text style={s.label}>Escolha o horário:</Text>
                    <TouchableOpacity
                        style={s.selectBox}
                        onPress={() => setShowTimeModal(true)}
                    >
                        <Text style={s.selectText}>
                            {selectedTime || "Selecione um horário"}
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
            <View style={s.buttonArea}>
                <Button title="Reservar" onPress={handleBuyButton} />
            </View>

            {/* Modal para Datas */}
            <Modal visible={showDateModal} transparent animationType="slide">
                <View style={s.modalContainer}>
                    <FlatList
                        data={dates}
                        keyExtractor={(item) => item}
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                style={s.modalItem}
                                onPress={() => {
                                    setSelectedDate(item);
                                    setShowDateModal(false);
                                }}
                            >
                                <Text style={s.modalText}>{item}</Text>
                            </TouchableOpacity>
                        )}
                    />
                </View>
            </Modal>

            {/* Modal para Horários */}
            <Modal visible={showTimeModal} transparent animationType="slide">
                <View style={s.modalContainer}>
                    <FlatList
                        data={times}
                        keyExtractor={(item) => item}
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                style={s.modalItem}
                                onPress={() => {
                                    setSelectedTime(item);
                                    setShowTimeModal(false);
                                }}
                            >
                                <Text style={s.modalText}>{item}</Text>
                            </TouchableOpacity>
                        )}
                    />
                </View>
            </Modal>
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    container: {
        flex: 1,
    },
    area: {
        flex: 1,
        padding: 10,
    },
    buttonArea: {
        padding: 10,
    },
    img: {
        width: "100%",
        height: 250,
        borderRadius: 10,
        marginBottom: 20,
    },
    campo: {
        gap: 10,
    },
    title: {
        fontSize: 30,
        fontWeight: "bold",
    },
    description: {
        fontSize: 15,
        fontStyle: "italic",
    },
    price: {
        color: "green",
        fontSize: 20,
        fontWeight: "bold",
    },
    inputArea: {
        marginTop: 20,
    },
    label: {
        fontSize: 16,
        fontWeight: "bold",
        marginBottom: 5,
    },
    selectBox: {
        width: "100%",
        height: 50,
        borderWidth: 1,
        borderColor: "#ddd",
        borderRadius: 10,
        justifyContent: "center",
        paddingHorizontal: 15,
        marginBottom: 15,
        backgroundColor: "#fff",
    },
    selectText: {
        fontSize: 16,
        color: "#333",
    },
    modalContainer: {
        flex: 1,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        justifyContent: "center",
        padding: 20,
    },
    modalItem: {
        padding: 15,
        backgroundColor: "#fff",
        borderRadius: 5,
        marginBottom: 10,
    },
    modalText: {
        fontSize: 16,
        color: "#333",
    },
});
