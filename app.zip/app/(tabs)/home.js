import { useState, useEffect } from "react"
import { StyleSheet, View, Text, FlatList, Image } from "react-native"
import { getAllProducts } from "../../services/product"
import { ProductItem } from "../../components/product-item"

export default function Screen(){
    const [products, setProducts] = useState([])
    const [bannerIndex, setBannerIndex] = useState(0)  // Estado para controlar a imagem do banner

    // Array de URLs de imagens para o banner
    const bannerImages = [
        'https://i.postimg.cc/14YtXNDD/bar4.jpg',
        'https://i.postimg.cc/tn74DXG1/bar2.jpg',
        'https://i.postimg.cc/w7yBmTkZ/bar5.jpg',
    ]

    // Efeito para buscar os produtos
    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const fetchedProducts = await getAllProducts()
                setProducts(fetchedProducts)
            } catch (error) {
                console.error("Erro ao carregar produtos:", error)
            }
        }
        fetchProducts()

        // Intervalo para trocar a imagem do banner a cada 5 segundos
        const interval = setInterval(() => {
            setBannerIndex((prevIndex) => (prevIndex + 1) % bannerImages.length)
        }, 5000)

        // Limpar o intervalo quando o componente for desmontado
        return () => clearInterval(interval)
    }, [])  // O array vazio faz o efeito rodar apenas uma vez quando o componente é montado

    return (
        <View style={s.container}>
            {/* Banner que troca de imagem a cada 5 segundos */}
            <View style={s.banner}>
                <Image source={{ uri: bannerImages[bannerIndex] }} style={s.bannerImage}/>
            </View>

            {/* Exibe a lista de produtos */}
            {products.length > 0 ? (
                <FlatList
                    data={products}
                    renderItem={({ item }) => <ProductItem data={item} />}
                    keyExtractor={item => item.id.toString()}
                    style={s.list}
                />
            ) : (
                <Text>Carregando produtos...</Text> // Exibe uma mensagem enquanto carrega os produtos
            )}
        </View>
    )
}

const s = StyleSheet.create({
    container: {
        flex: 1,
    },
    banner: {
        width: '100%',
        height: 200,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
        overflow: 'hidden',  // Garante que a imagem não estoure os limites do container
    },
    bannerImage: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    list: {
        flex: 1,
        width: '100%',
        paddingTop: 10,
    },
})
