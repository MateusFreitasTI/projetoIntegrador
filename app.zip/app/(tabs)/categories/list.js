import { StyleSheet, View, Text, FlatList, Pressable, Image } from "react-native"
import { getAllCategories } from "../../../services/category"
import { router } from "expo-router"
import { data } from "../../../assets"


export default function Screen() {

    const categories = getAllCategories()

    const handleClick = (item) => {
        router.push(`/categories/${item.id}`)
    }

    return (
        <View style={s.containerGeral}>
            <FlatList data={categories} renderItem={({ item }) =>


                <Pressable style={s.container} onPress={() => handleClick(item)}>
                    <Image style={s.img} source={{ uri: item.cover }} resizeMode="cover" />
                    <View style={s.bg}></View>
                    <View style={s.box}>
                        <Text style={s.title}>{item.title}</Text>
                    </View>
                </Pressable>


            } keyExtractor={(item) => item.id.toString()} />
        </View>
    )
}

const s = StyleSheet.create({
    containerGeral: {
        flex: 1,
    },
    container: {
        margin: 10,
        backgroundColor: '#333333',
        borderRadius: 10
    },
    list: {
        flex: 1,
        width: '100%',
        padding: 20
    },
    img: {
        width: '100%',
        height: 150,
        borderRadius: 10
    },
    bg: {
        height: 150,
        marginTop: -150,
        backgroundColor: '#000000',
        opacity: 0.6,
        borderRadius: 10
    },
    box:{
        height: 150,
        marginTop: -150,
        justifyContent: 'center',
        alignItems: 'center',
    },
    title:{
        fontSize: 24,
        color: 'white',
    }
})