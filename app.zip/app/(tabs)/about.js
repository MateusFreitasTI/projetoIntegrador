import { SafeAreaView, StyleSheet, Text, Image, View } from "react-native";

export default function About() {
  return (
    <SafeAreaView style={s.container}>
      <Image source={require('../../assets/userBest.webp')} style={s.logo} resizeMode="contain"/>
      <Text style={s.h1}>Dados do Usuário</Text>
      <View style={s.dados}>
        <Text style={s.label}>Nome:  exemplo</Text>
        <Text style={s.label}>Email:  exemplo@gmail.com</Text>
        <Text style={s.label}>CPF:  123123123-12</Text>
        
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo:{
    width: 300,
    height: 200,
    marginBottom: 10
  },
  h1:{
    fontWeight: 'bold',
    marginBottom: 60,
    fontSize: 30
  },
  dados:{
    width: 300,
    height: 'auto',
    gap: 20,
    borderColor: 'black',
    borderWidth: 2,
    borderRadius: 30,
    padding: 30
  },
  label:{
    fontWeight: 'bold',
  }
});